"""Hyperparameter an einer Stelle (gut fuer die Folie "Training configuration")."""
from __future__ import annotations

from dataclasses import dataclass, asdict, fields


@dataclass
class AgentConfig:
    # --- Netz
    hidden: int = 256
    dueling: bool = True

    # --- DQN
    gamma: float = 0.99
    lr: float = 3e-4
    batch_size: int = 256
    buffer_capacity: int = 300_000
    learn_start: int = 5_000          # Env-Steps, bevor gelernt wird
    train_every: int = 2              # Lernschritt alle n Env-Steps
    target_update_every: int = 500    # harte Target-Sync alle n Lernschritte
    grad_clip: float = 5.0
    double_dqn: bool = True

    # --- Exploration (lineares Epsilon-Decay ueber Env-Steps)
    eps_start: float = 1.0
    eps_end: float = 0.05
    eps_decay_steps: int = 60_000
    guided_prob: float = 0.7
    """Anteil der Explorationsschritte, die NICHT uniform zufaellig sind, sondern
    heuristisch Richtung zugewiesenes Ziel laufen. Ohne diesen Prior erreichen die
    Units aus der Spawn-Ecke die Relic-Zonen praktisch nie und der w_point-Reward
    wird nie gesehen (im Experiment: Recall der Punkte-Tiles ~5%)."""

    # --- Ablations-Schalter (docs/EXPERIMENT_PROTOKOLL.md). Jede Ablation
    # schaltet genau EINEN davon gegenueber "full" um.
    use_belief: bool = True
    """False: das Netz sieht nur die aktuelle Beobachtung (MemorylessBelief).
    Reward, Maske und gefuehrte Exploration nutzen weiter den vollen Belief."""
    use_symmetry: bool = False
    """True: Belief nutzt die Spiegelsymmetrie der Karte (Relics, Punkte-/Null-Tiles,
    Erkundung, siehe belief.py). Default False, damit alte Checkpoints und
    Experimente unveraendert reproduzierbar bleiben (from_dict fuellt fehlende
    Schluessel mit dem Default)."""
    home_first: bool = False
    """True: Zielzuweisung bestraft Ziele in der gegnerischen Haelfte (+600, d. h.
    eigene Punkte-Tiles < gegnerische Punkte-Tiles < eigene Kandidaten < ...)."""
    home_penalty: float = 0.0
    """> 0: ueberschreibt die Kosten fuer Ziele in der gegnerischen Haelfte
    (home_first nutzt 600). 1500 ordnet: eigene Punkte-Tiles < eigene Kandidaten
    < gegnerische Punkte-Tiles < Erkundung (Prioritaetsstufen kosten je 1000)."""
    home_last_only: bool = False
    """True: home_first/home_penalty nur im letzten Match (Analyse 19.10.: in
    Match 3 laufen ~4,7 Units zu Punkte-Tiles der Gegnerhaelfte, 0,4 besetzt)."""
    explore_memory: bool = False
    """True: Erkundung bevorzugt Tiles, die in KEINEM bisherigen Match gesehen
    wurden (+300 Kosten fuer frueher gesehene, siehe features.assign_targets)."""
    # --- Match-1-Schalter (12.10.2026, Analyse scripts/analyze_timing.py: wir sehen
    # das erste Relic im Median 10 Steps nach Solution_92, in 12/80 Matches nie).
    explore_grid: bool = False
    """True: Erkundungsziele = je ein unerkundetes Tile pro 4x4-Block statt der
    unerkundeten Tiles am naechsten zum Schwerpunkt -> Units verteilen sich."""
    scripted_explore: bool = False
    """True: Hat eine Unit nur ein Erkundungsziel (kein Punkte-/Kandidaten-Tile),
    laeuft sie heuristisch dorthin statt der Netz-Aktion (ausser Sap). Das Netz
    hat gelernt, am Matchanfang auf Energiefeldern nahe dem Spawn zu warten."""
    explore_stale: int = 0
    """> 0: In Match 0, solange kein Relic bekannt ist, gilt ein Tile nur als
    erkundet, wenn es in den letzten `explore_stale` Steps oder ab match_step 49
    gesehen wurde - das Relic-Paar spawnt erst bei match_step 0..49, Gebiete von
    vorher koennen es verbergen. 0 = aus."""
    early_inference: bool = False
    """True: Punkte-Tile-Schluesse schon vor match_step 50, sobald das Relic-Paar
    des aktuellen Matches sicher gespawnt ist (siehe Belief._stable)."""
    relic_filter: bool = False
    """True: Punkte-Schluesse ignorieren Units ausserhalb jeder moeglichen
    Relic-Reichweite (Belief._possible_point_zone, Idee aus Solution_92)."""
    subset_infer: bool = False
    """True: zusaetzlich Differenzen von Teilmengen-Beobachtungen auswerten
    (Belief._add_differences) und doppelte Gleichungen nicht speichern."""
    overlap_infer: bool = False
    """True: sichere Extremfaelle teilweise ueberlappender Punkte-Gleichungen
    auswerten; nur neue gegen hoechstens 400 vorhandene Gleichungen zu je 16 Tiles."""
    cand_quota: int = 0
    """> 0: so viele eigene Kandidaten-Tiles rangieren vor den Punkte-Tiles der
    Gegnerhaelfte (features.assign_targets)."""
    sticky: float = 0.0
    """> 0: Kostenabzug (in Feldern), wenn eine Unit ihr Ziel aus dem vorigen
    Step behaelt (20.10.2026). Diagnose: 15-24 % aller Unit-Schritte wechselten
    das Ziel, obwohl das alte noch gueltig war (features.assign_targets)."""
    far_opp: int = 0
    """> 0: Punkte-Tiles der Gegnerhaelfte, die weiter als far_opp Felder von der
    Unit entfernt sind, rangieren hinter den Kandidaten-Tiles (20.10.2026,
    features.assign_targets)."""
    far_cand: bool = False
    """True (mit far_opp): auch Kandidaten der Gegnerhaelfte, die weiter als far_opp
    entfernt sind, rangieren hinter den eigenen Kandidaten (20.10.2026)."""
    cand_boost: float = 0.0
    """> 0: eigene Kandidaten-Tiles rangieren wie Punkte-Tiles mit cand_boost Feldern
    Zusatzweg, Punkte-Tiles der Gegnerhaelfte bekommen denselben Zuschlag."""
    contest_sap: bool = False
    """True: steht auf dem Ziel-Tile ein Gegner, den die Unit per Kollision nicht schlaegt,
    sappt sie dieses Tile aus der Entfernung (main._contest_sap)."""
    energy_pref: float = 0.0
    """> 0: Punkte-Tiles mit hoher Feldenergie bevorzugen (energy_pref Felder Umweg je 10 Energie)."""
    explore_quota: int = 0
    """> 0: so viele Units suchen in Match 2/3 gezielt das Relic-Paar, solange es fehlen
    kann (bis explore_until), Ziel: lange nicht gesehene Tiles der eigenen Haelfte."""
    explore_until: int = 75
    pt_sap: bool = False
    """True: Unit auf eigenem Punkte-Tile, deren Netz-Aktion 'stehen' ist, sappt
    stattdessen ein sichtbares Ziel in Reichweite (bleibt dabei auf dem Tile)."""
    pt_sap_reserve: int = 0
    """Energie, die nach dem Sap mindestens uebrig bleiben muss (pt_sap)."""
    pt_sap_zone: bool = False
    """True (mit pt_sap): auch gestapelte Units und Units auf Kandidaten-Tiles sappen."""
    safe_moves: bool = False
    """True: Aktionsmaske verbietet Zuege auf ein Tile mit sichtbarem Gegner, dessen
    Energie mindestens so gross ist wie die eigene nach dem Zug (Kollision verloren)."""
    idle_sap: bool = False
    """True: jede Unit, deren Netz-Aktion 'stehen' ist, sappt ein Ziel in Reichweite,
    wenn danach noch idle_sap_reserve Energie bleibt (auch abseits der Punkte-Tiles)."""
    idle_sap_reserve: int = 30
    art_sap: bool = False
    """True (21.10.2026): Unit, die nicht als Erste auf einem Punkte-Tile steht, sappt
    statt ihrer Netz-Aktion, wenn das Ziel mindestens art_min_hits Gegner trifft,
    danach art_reserve Energie bleibt und (art_safe) kein sichtbarer Gegner mit
    Energie >= Sap-Kosten sie in Manhattan-Reichweite hat. Solution_92 prueft die
    Sap-Reichweite nach Manhattan, die Engine erlaubt das ganze Quadrat (Chebyshev)."""
    art_move_guard: bool = False
    """Unnoetigen erzwungenen Artillerie-Sap vorab abweisen und den erlaubten Zug
    durch die normale Bewegungssicherung weiterpruefen (nur mit sap_no_overkill)."""
    art_min_hits: int = 2
    art_reserve: int = 0
    art_safe: bool = True
    art_splash: bool = False
    """True (30.10.2026): Ist der Sap-Streufaktor laut param_est sicher 1,0, gilt fuer art_sap
    art_min_hits=art_splash_hits und kein art_safe (voller Streuschaden: zwei Treffer im 3x3 lohnen auch
    in gegnerischer Reichweite). Dev A, V10 gegen Solution_92/sol92_sq, art_safe=false + art_min_hits=2
    nach Streufaktor 0,25/0,5/1,0: −6,5/−0,8/+6,0 pp. Dev B mit art_splash: +0,8 pp, bei 1,0 +3,1 pp."""
    art_splash_in_training: bool = False
    """True (08.11.2026): vorhandene art_splash-Regel samt Parameterschaetzung auch im Training.
    Ohne art_splash wirkungslos; die Inferenz bleibt unveraendert."""
    art_splash_hits: int = 2
    sap_still_splash: bool = False
    """True (30.10.2026, mit sap_still): Ist der Streufaktor laut param_est sicher 1,0, duerfen Halter auch
    ziehende Gegner direkt sappen: Die Engine bewegt vor dem Sap, ein Gegner einen Schritt neben dem Zieltile
    bekommt dann den vollen Schaden. Dev B zusaetzlich zu art_splash: +0,7 pp, bei 1,0 +2,7 pp."""
    splash_min_drop: float = 1.0
    """30.10.2026: art_splash und sap_still_splash greifen ab diesem sicher geschaetzten Streufaktor
    (Standard 1,0 wie in V11; 0,5 nimmt den Streufaktor 0,5 dazu). V11 mit 0,5 auf Dev A gepaart gegen V11:
    Mittel ueber 6 Gegner +0,8 pp [-0,2; +1,9], Karten mit Streufaktor 0,5 +2,6 [-0,8; +5,9]."""
    splash_safe_below: float = 0.0
    """30.10.2026: art_splash verzichtet erst ab diesem sicher geschaetzten Streufaktor auf art_safe (0,0 = immer
    wie V11; 1,0 = bei 0,5 mit splash_min_drop=0.5 bleibt die Sicherheitspruefung). Diagnose: die Halbstreuung
    kostet gegen Solution_92 bei 0,5 -1,5 pp, Artillerie ohne Sicherheit steht dort in dessen Reichweite."""
    art_surplus: bool = False
    """True (22.10.2026): art_sap nicht fuer Units, deren Ziel ein Punkte-Tile der eigenen Haelfte ist."""
    threat_feats: bool = False
    """True (21.10.2026): Netz-Eingabe um features.THREAT_NAMES erweitert (Gefahr je Tile,
    bester Sap). Andere Eingabegroesse -> nur fuer neu trainierte Netze."""
    dodge: bool = False
    """True (21.10.2026, nur Auswertung): Units, die stehen/sappen wuerden und laut
    opp_model von Solution_92 direkt beschossen werden, weichen einen Schritt aus."""
    dodge_mode: str = "lethal"
    dodge_verify: bool = False
    """True (22.10.2026, nur Auswertung): dodge/dodge_auto erst, wenn sich die Vorhersage des
    Solution_92-Modells in diesem Spiel bestaetigt (>= 3 Faelle, >= 60 % direkte Treffer bei
    stehen gebliebenen vorhergesagten Zielen). Gegen anders zielende Gegner bleibt es aus."""
    dodge_distrust: float = 0.0
    """> 0 (30.10.2026): wie dodge_verify, aber umgekehrt - das Gegnermodell gilt von Anfang an und wird erst
    abgeschaltet (auch fuer splash_dodge), wenn nach >= 6 stehen gebliebenen vorhergesagten Zielen weniger als
    dieser Anteil direkt getroffen wurde (Gegner zielt anders als Solution_92, z. B. RL-Agents)."""
    dodge_shape: bool = False
    """True (30.10.2026): opp_model fuer dodge/dodge_auto erkennt die Sap-Form des Gegners im Spiel.
    Solution_92 zielt in der Manhattan-Raute, die Variante sol92_sq (wie die Engine erlaubt) im ganzen
    Quadrat. Eigene Units, die nur eine der beiden Formen als Ziel vorhersagt und die stehen bleiben,
    zeigen im naechsten Step mit einem direkten Treffer, welche Form stimmt. Das Quadrat gilt, sobald
    es mehr Treffer hat als die Raute (vorher Raute wie bisher). Diagnose V11 gegen sol92_sq (Dev A):
    in verlorenen Matches 2/3 feuert der Gegner doppelt so oft, wir verlieren 16-17 statt 9 Units."""
    splash_dodge: bool = False
    """True (30.10.2026): Bei sicher geschaetztem Streufaktor >= 0,5 weichen stehende Units, die neben
    vorhergesagten Zielen (opp_model, mit dodge_shape auch Quadrat) stehen und mindestens splash_dodge_min
    ihrer Energie als Streuschaden bekaemen, einen Schritt aus. Diagnose V11 gegen sol92_sq (Dev A,
    verlorene Matches 2/3): Streuschaden auf uns 2.016 (Streufaktor 1,0) bzw. 1.190 (0,5), direkt 651/688."""
    splash_dodge_min: float = 0.5
    rules_in_training: bool = False
    """True (22.10.2026): path_fix, reach_assign, sap_no_overkill und collision_guard auch im Training
    aktiv (sonst nur in der Auswertung), damit neue Netze unter V8-Bedingungen lernen."""
    rules_in_training_all: bool = False
    """True (26.10.2026): zusaetzlich sap_still und die Nebel-Meidung (mit Parameterschaetzung) im
    Training aktiv. Mit rules_in_training lernen neue Netze dann unter allen V10-Regeln."""
    neb_cand: bool = False
    """True (22.10.2026): Kandidaten-Tiles im schaedlichen Nebel (>= nebula_avoid_min) betreten und
    dort bleiben duerfen; wartende Units mit solchem Ziel in <= 3 Schritten gehen hin."""
    idle_approach: bool = False
    """True (22.10.2026, mit neb_cand): wartende Unit ohne nahen Gegner geht zu ihrem Kandidaten-Ziel,
    wenn es hoechstens 3 BFS-Schritte entfernt ist (auch ausserhalb von Nebel)."""
    obey_target: bool = False
    """True (22.10.2026): ohne nahen Gegner kein Zug weg vom zugewiesenen Punkte-/Kandidaten-Tile
    (BFS-Distanz waechst) -> erster Schritt des kuerzesten Wegs."""
    mobile_seen: bool = False
    """True (22.10.2026): collision_guard/holder_guard zaehlen Gegner, die im letzten Step am selben
    Ort standen, nicht als beweglich (nicht nur Gegner auf bekannten Punkte-Tiles)."""
    holder_guard: bool = False
    """True (22.10.2026): stehende Unit weicht aus, wenn ein beweglicher, mindestens gleich starker
    sichtbarer Gegner kardinal daneben steht (er zieht sonst oft auf unser Tile)."""
    collision_guard: bool = False
    """True (22.10.2026): Zuege sperren, wenn ein beweglicher, mindestens gleich starker sichtbarer
    Gegner im selben Step auf dasselbe Tile ziehen kann (Kollisionstod)."""
    window_infer: bool = False
    """True (22.10.2026): Punkte-Tile-Inferenz auch in den ersten 50 Steps von Match 2/3 (Spawnfenster
    neuer Relics), wenn um jede eigene Unit das 5x5-Feld sichtbar ist. Diagnose V8-Verlustspiele: in
    Match 2/3 bleiben ~2 echte eigene Punkte-Tiles pro Step ungetestete Kandidaten bekannter Relics."""
    window_infer_all: bool = False
    """True (22.10.2026): im Spawnfenster immer schliessen; Unit-Tiles ohne ganz sichtbares 5x5-Feld
    zaehlen als offene Unbekannte (ein ungesehenes neues Relic koennte sie punkten lassen)."""
    stage_attack: bool = False
    """True (22.10.2026): Units warten vor der Schusszone gegnerischer Sammler, bis stage_min eigene Units
    mit Ziel in der Zone davor stehen (gemeinsam statt einzeln hinein)."""
    stage_min: int = 3
    stage_until: int = 70
    cand_rescue: bool = False
    """True (22.10.2026): nur wenn trotz bekannter Relics kein Punkte-Tile bekannt ist, werden obey_target,
    neb_cand und idle_approach aktiv (Kandidaten gezielt testen). Sicherheitsnetz fuer 0-Punkte-Spiele."""
    cand_stall_rescue: bool = False
    """Nur Auswertung: Kandidatenziele in Match 0 nach 12 oeffentlich beobachteten
    Uebergaengen ohne Fortschritt frueh retten. Der alte cand_rescue-Timer bleibt erhalten."""
    rescue_after: int = 0
    """cand_rescue greift erst, wenn das erste Relic seit mindestens so vielen Steps bekannt ist."""
    rescue_in_training: bool = False
    """Opt-in fuer Rettungs-Nachtraining: nur aktive cand-/zone_rescue-Eingriffe auch beim Lernen.
    Schaltet eigenstaendige obey_target/neb_cand-Regeln nicht frei; Inferenz bleibt unveraendert."""
    zone_rescue: bool = False
    """True (01.11.2026, nur Auswertung): cand_rescue je Relic-Zone. Units mit einem Kandidaten-Ziel in der 5x5-Zone eines
    Relics, das seit rescue_after Schritten bekannt ist und in dessen Zone noch kein Punkte-Tile bewiesen ist, testen
    gezielt (obey_target, neb_cand, idle_approach), auch wenn anderswo schon Punkte-Tiles bekannt sind. cand_rescue
    allein greift nur ohne jedes bekannte Punkte-Tile, im 2./3. Match also kaum. cand_rescue brachte auf frischen
    Karten +0,86 pp, alle 6 Gegner im Plus (V14)."""
    art_safe_cheb: bool = False
    """True (22.10.2026): art_safe prueft die Gefahr im ganzen Sap-Quadrat (Chebyshev, wie die Engine)
    statt in der Manhattan-Raute von Solution_92. Robustheit gegen Gegner, die diagonal sappen."""
    art_still: bool = False
    """True (22.10.2026): art_sap nur, wenn ein stehender Gegner direkt oder mindestens zwei stehende
    im 3x3-Bereich getroffen werden (wie sap_still, nur fuer die Artillerie-Regel)."""
    sap_still_all: bool = False
    """True (22.10.2026): wie sap_still, aber fuer jedes Sap (Netz, Artillerie, Halter): nur wenn ein
    stehender Gegner direkt oder mindestens zwei stehende im 3x3-Bereich getroffen werden."""
    sap_still: bool = False
    """True (22.10.2026): pt_sap nur auf stehende Gegner (unbewegt im letzten Step oder auf bekanntem
    Punkte-Tile); ziehende Ziele weichen dem direkten Treffer aus."""
    sap_relevant: bool = False
    """True (22.10.2026): pt_sap nur auf Gegner auf/neben bekannten Punkte-Tiles, nicht auf
    durchziehende Erkunder (Energie der Halter schonen)."""
    sap_no_overkill: bool = False
    """True (22.10.2026): kein Sap auf Gegner, die durch schon geplante Saps desselben Steps sicher
    sterben (ohne weiteren lebenden Gegner daneben) -> Energie behalten statt Mehrfach-Treffer."""
    sap_overkill_recovery: bool = False
    """True (22.10.2026, mit sap_no_overkill): vor einer Sap-Stornierung die maximale positive
    Feld-Erholung beruecksichtigen. Null Energie ueberlebt; geplante Treffer setzen Zielpositionen voraus."""
    sym_map: bool = False
    """True (22.10.2026): sichtbare Tiles fuellen auch ihr Spiegeltile (Typ und Feldenergie). Die
    Karte ist in allen geprueften Zustaenden exakt symmetrisch (auch nach Drift); Solution_92 nutzt das."""
    sap_reserve_k: float = 0.0
    """22.10.2026: Regel-Saps (pt_sap, art_sap) nur mit Energie >= Sap-Kosten * (1 + k) (+ alte
    absolute Reserven). Diagnose V7-Verlustspiele: Halter haben 60-84 statt 82-115 Energie, wir
    sappen 2-3x so oft wie Solution_92; 74 % der Toten hatten weniger Energie als ein Sap kostet."""
    unstack: bool = False
    """True (22.10.2026): gestapelte Unit (Punkte-Tile gehoert schon einer anderen eigenen Unit)
    wartet nicht, sondern geht per BFS-Schritt zu ihrem zugewiesenen Ziel."""
    reach_assign: bool = False
    """True (22.10.2026): Zielzuweisung nach BFS-Weglaenge ueber die Gedaechtniskarte statt
    Luftlinie; unerreichbare Ziele (z. B. Punkte-Tiles unter Asteroiden) nur als letzte Wahl."""
    point_pair_swap: bool = False
    """Hoechstens einen strikt besseren BFS-Eigentuermertausch zwischen bereits
    zugewiesenen eigenen Punktzielen vor den Features pruefen (voller Belief)."""
    drift_track: bool = False
    """True (22.10.2026): Drift von Asteroiden/Nebel erkennen (sichtbare Tiles passen zur um
    (s, -s) gerollten Erinnerung) und die ganze Gedaechtniskarte mitrollen."""
    path_fix: bool = False
    """True (22.10.2026): Zug, der nach Luftlinie naeher ans Ziel fuehrt, auf dem BFS-Weg aber
    nicht (Sackgasse an Asteroidenwand), durch den ersten Schritt des kuerzesten Wegs ersetzen.
    Diagnose 360581: Units pendeln zwischen Wand und Sackgasse und verlieren alle Energie."""
    nebula_infer: bool = False
    """True (22.10.2026): Tiles in Sensorreichweite eigener Units, die unsichtbar sind, sind Nebel.
    Behebt veraltete Asteroiden im Gedaechtnis (Drift), die bei kleiner Sicht Wege sperren
    (z. B. Units eingesperrt am Spawn, 360014)."""
    nebula_infer_drift_safe: bool = False
    """True (22.10.2026, mit nebula_infer): auf erkannter Drift keine Nebel-Inferenz aus dem
    Sensor vor der Drift. Nicht erkannte Drift bleibt eine Grenze der Inferenz."""
    dodge_bait: bool = False
    """True (22.10.2026): beim Ausweichen in Manhattan-Reichweite der Schuetzen bleiben (Koeder:
    Solution_92 zielt auf unsere hoechste ID in Reichweite) und nicht neben eigene Units ziehen."""
    dodge_auto: bool = False
    dodge_auto_max: float = 0.5
    """Hoechster geschaetzter Streufaktor, bei dem dodge_auto ausweicht. 22.10.2026: Gewinn fast
    nur bei 0,25 (schwere Karten +2,7 pp), bei 0,5 leichte Karten −1,7 pp."""
    """True (22.10.2026, nur Auswertung): dodge (mit dodge_mode) nur, solange der geschaetzte
    Sap-Streufaktor (param_est, sonst 0,5) <= 0,5 ist. Entwicklung 500720-500779: dodge always
    bei Streufaktor 0,25 / 0,5 / 1,0: +5,9 / +2,5 / −2,2 pp."""
    """'lethal': nur ausweichen, wenn Stehenbleiben vermutlich toetet; 'always': immer."""
    tactics_when_behind: bool = False
    """True (21.10.2026): dodge und art_sap greifen nur, wenn wir im laufenden Match nach Punkten
    hinten liegen. Entwicklung: beide helfen auf schweren Karten (+10 bis +14 pp), kosten aber
    auf leichten Karten 2-3 pp."""
    nebula_avoid: bool = False
    """True (21.10.2026, nur Auswertung): geschaetzter Nebel-Energieabzug (param_est) >=
    nebula_avoid_min -> keine Zuege in Nebel ohne Punkte-Tile; bei >= 25 verlassen Units den Nebel.
    Analyse 2000 Karten: V3 gegen Solution_92 bei Nebelabzug 25 nur 65,5 % statt ~78 %."""
    nebula_avoid_min: int = 25
    nebula_avoid_mode: str = "mask"
    """'mask' (Zuege in Nebel gesperrt, V5-B) oder 'soft' (Umweg/Wartezeit statt Sperre)."""
    """Ab diesem geschaetzten Abzug greift nebula_avoid. 22.10.2026: bei 5 auf 60 Karten mit
    Nebelabzug 5 −16,7 pp (Units erreichen ihre Ziele nicht mehr), bei 25 auf 100 Karten +5,0 pp."""
    sap_dropoff_est: bool = False
    """True (22.10.2026, nur Auswertung): Sap-Zielwertung mit dem geschaetzten Streufaktor
    (param_est) statt der festen Annahme 0,5."""
    stack_guard: bool = False
    """True (22.10.2026, nur Auswertung): keine Zuege auf ein Punkte-Tile, auf dem schon eine
    eigene Unit steht (Stapeln bringt keinen Punkt und verdoppelt Sap-Schaden)."""
    relic_search: bool = False
    """True (22.10.2026, nur Auswertung): ein fester Sucher sucht in Match 2/3 das neue Relic-Paar
    (features.relic_search), solange es fehlen kann."""
    relic_search_until: int = 75
    relic_search_stale: int = 25
    siege: bool = False
    """True (21.10.2026, nur Auswertung): Units, deren Ziel ein vom Gegner (sichtbar oder
    wahrscheinlich im Nebel) besetztes Punkte-Tile ist, laufen nicht hinein, sondern zur
    naechsten Schussposition ausserhalb seiner Manhattan-Reichweite und sappen von dort
    (rules.SiegePlan). Fehlt Energie, warten sie dort."""
    siege_min_score: float = 1.5
    """Mindestens erwartete getroffene Gegner (direkt 1, daneben 0,5) fuer einen Schuss."""
    siege_reserve: float = 0.0
    siege_prob: float = 0.5
    """Ab dieser Besetzungswahrscheinlichkeit zaehlt ein Nebel-Punkte-Tile zur Festung."""
    sap_kill_first: bool = False
    """True: Sap-Ziel bevorzugt Gegner, die der direkte Treffer zerstoert (Energie < Sap-Kosten)."""
    sap_kill_safe: bool = False
    """True (22.10.2026): Sap-Ziel bevorzugt lebende Gegner, die der direkte Treffer sicher toetet
    (Energie + Feldgewinn < Sap-Kosten). Korrigiert sap_kill_first, das auch schon tote Gegner
    (Energie < 0, verschwinden vor dem Sap) bevorzugte."""
    sap_pt_first: bool = False
    """True: Sap-Ziel bevorzugt Gegner auf bekannten Punkte-Tiles (_best_sap_target)."""
    sap_geometry: bool = False
    """True: bei bereits vorhandenem Sap-Ziel weitere legale Zentren pruefen;
    nur strikt hoeherer bisheriger Energiescore ersetzt das Ziel. Keine neue Sap-Maske."""
    keep_dead: bool = False
    """True: Null-Tiles frueherer Matches gelten wieder, sobald feststeht, dass
    sie nicht neben einem neuen Relic liegen (Belief._restore_dead)."""
    keep_dead_fast: bool = False
    """True: wie Solution_92 - Null-Tiles bleiben ueber Matchgrenzen gueltig, nur
    Tiles neben NEU gefundenen Relics werden wieder offen (Risiko: ein noch
    ungesehenes neues Relic; Widersprueche oeffnen dann alles)."""
    stale_all: bool = False
    """True: explore_stale gilt in JEDEM Match, solange das Relic-Paar dieses
    Matches noch unbekannt ist (neue Paare spawnen auch in frueher gesehenen
    Gebieten)."""
    opp_infer: bool = False
    """True: Null-Tiles auch aus dem Punktgewinn des Gegners (Belief._infer_from_enemy)."""
    opp_point_infer: bool = False
    """True (29.10.2026): Punkte-Gleichungen auch aus dem Punktgewinn des Gegners, wenn jedes moegliche
    Punkte-Tile gerade sichtbar ist (Belief._infer_points_from_enemy). Hilft auf Haufen, die der Gegner zuerst besetzt."""
    # --- Regel-Schalter (19.10.2026, rules.py). Default aus.
    pt_walk: bool = False
    """True: Units, deren Ziel ein bewiesenes Punkte-Tile ist, laufen auf dem
    kuerzesten Weg (BFS) dorthin statt der Netz-Aktion (ausser Sap)."""
    pt_walk_own: bool = False
    """pt_walk nur fuer Punkte-Tiles der eigenen Haelfte."""
    pt_walk_from_match: int = 0
    """pt_walk erst ab diesem Match (0 = immer)."""
    pt_hold: bool = False
    """True: eine Unit, die als Erste auf einem bewiesenen Punkte-Tile steht,
    verlaesst es nicht (Netz darf nur stehen oder sappen)."""
    ram: bool = False
    """True: Units fahren auf Nachbar-Tiles mit schwaecheren Gegnern und
    zerstoeren sie per Kollision (rules.ram_move)."""
    ram_margin: float = 10.0
    fog_sap: bool = False
    """True: Units auf bewiesenen Punkte-Tiles, die stehen wuerden, sappen auf
    unsichtbare Gegner-Punkte-Tiles, wenn der Gegner-Punktgewinn versteckte
    Besetzer verraet (rules.fog_sap)."""
    fog_any: bool = False
    """True: Nebel-Sap fuer jede stehende Unit, nicht nur auf Punkte-Tiles."""
    fog_reserve: float = 30.0
    fog_sap_max_sensor: int = 4
    """fog_sap nur bei Sensorreichweite <= diesem Wert (22.10.2026: Schwachstelle Sicht 1-2)."""
    fog_v2: bool = False
    """True (31.10.2026, mit fog_sap): Sichtbar ist nur, was der Sensor gerade wirklich zeigt. Mit use_symmetry
    gilt das Spiegelbild des Sensors in belief.last_seen als gesehen, die gegnerischen Punkte-Tiles (Spiegelbild
    unserer) fielen deshalb aus den Kandidaten. Dazu Kandidaten in beiden Haelften ohne eigene Unit, sichtbare
    Besetzer je Tile einmal gezaehlt, und kein Nebel-Sap, wenn die Unit ein sichtbares Ziel hat. Diagnose V11 bei
    Sicht 1: 97 % der gegnerischen Halter unsichtbar, 28-343 Unit-Steps je Spiel mit unsichtbarem Halter in
    Reichweite, dort nie ein Sap."""
    """Energie, die nach einem Nebel-Sap mindestens uebrig bleiben soll."""
    fog_prior: bool = False
    """True (31.10.2026, mit fog_sap/fog_v2): Kandidaten des Nebel-Saps nach der letzten eigenen Beobachtung
    gewichtet statt gleich wahrscheinlich: zuletzt mit Gegner gesehen x fog_w_occ, zuletzt leer gesehen
    x fog_w_empty, in diesem Match nie gesehen x 1. Halter bleiben meist stehen. Offline auf 1.800 Dev-A-Spielen
    von V12 (21.170 Nebel-Saps, Wahrheit nach der Bewegung): direkte Treffer 41 statt 34 %, Schaden je Sap 45
    statt 40."""
    fog_w_occ: float = 4.0
    fog_w_empty: float = 0.25
    fog_drop_est: bool = False
    """True (31.10.2026): Zielwahl des Nebel-Saps mit dem sicher geschaetzten Streufaktor (param_est) statt fest
    0,5. Offline mit fog_prior bei Streufaktor 0,25: direkte Treffer 52 statt 36 %, bei 1,0 mehr Saps."""
    end_sap: int = 0
    """> 0 (31.10.2026): In den letzten end_sap Schritten eines Matches schiessen Units ihre Energie auf sichtbare
    Gegner: zuerst Halter (auf bekanntem Punkte-Tile, dann im letzten Step unbewegt), dann alle uebrigen, jeweils
    die mit der geringsten Restenergie nach den schon geplanten Saps: Abschuesse vor dem Matchende kosten den
    Gegner Punkte, Schaden an den uebrigen schwaecht Angreifer auf unsere Halter. Die
    Engine entfernt am Matchende alle Units, Restenergie zaehlt nur bei Punktgleichstand. Probe V12 (Dev A,
    120 Spiele gegen league_nets6/Solution_92): am Matchende verfallen im Mittel etwa 1.100 Energie je Match, in
    den letzten 10 Schritten 14-20 Unit-Schritte je Match mit Energie und sichtbarem Gegner in Reichweite ohne
    Sap. Units, die ein Punkte- oder Kandidaten-Tile noch rechtzeitig erreichen, laufen weiter; Halter behalten end_sap_hold
    Sap-Kosten Energie (ausser im letzten Schritt)."""
    end_sap_hold: float = 1.0
    est_censor: bool = False
    """True (01.11.2026): Die Parameterschaetzung (param_est) wertet keine Beobachtung mit Energie 0 aus. Die
    Engine kappt die Energie nach Feld und Nebel bei 0 (luxai_s3/env.py: clip(..., min_unit_energy=0, ...)). Eine
    Unit, die mit 0 Energie auf einem Nebel-Tile mit Feldenergie 0 steht, zeigte "Verlust 0" und galt als Beleg
    fuer Nebelabzug 0, jeder weitere Schritt verstaerkte das. Diagnose 812584 (Abzug 25, Bewegung 5, V12 gegen
    Solution_92): Die Schaetzung kippte in Match 1 bei Schritt 33 von 25 auf 0, die Nebel-Meidung war danach fuer
    das ganze Spiel aus, in Match 2 standen 3 von 4 verfolgten Units mit 0 Energie im Nebel fest (16:629)."""
    neb_cross: bool = False
    """True (01.11.2026): Die weiche Nebel-Meidung betritt Nebel nur mit Energie fuer die ganze Durchquerung:
    k Nebel-Tiles auf dem kuerzesten Weg zum Ziel x (Zugkosten + Nebelabzug) + ein Zug hinaus, statt pauschal
    2x Nebelabzug. Sonst Energie sammeln (stehen bleiben, auf negativem Feld zum besten Nachbarfeld ohne Nebel).
    Steckt die Unit schon im Nebel und reicht die Energie nicht bis zum Ausgang Richtung Ziel, nimmt sie den
    naechsten Ausgang."""
    no_strand: bool = False
    """True (01.11.2026): Kein Zug mit der letzten Zugenergie (danach Energie < Zugkosten) auf ein Feld ohne
    Energiegewinn (Feld minus geschaetzter Nebelabzug <= 0), ausser auf Punkte- und Kandidaten-Tiles. Stattdessen
    Energie sammeln (stehen bleiben oder bestes Nachbarfeld mit Gewinn). Die Engine kappt die Energie bei 0, eine
    solche Unit stand sonst bis zum Matchende fest (Diagnose 812256: Bewegung 4, Units 3-5 Felder vor der
    Relic-Ecke mit 0 Energie)."""
    reward_fix: bool = False
    """True: drei Reward-Korrekturen (Pruefung 14.10.): wiederverwendete Unit-IDs
    nach Tod gelten als Tod, kein Punkte-Reward bei negativer Energie, phi = 0
    im terminalen Matchende-Zustand. Default aus = alte Trainings reproduzierbar."""
    terminal_death_potential: bool = False
    """True: auch beim bereits erkannten Unit-Tod den terminalen Potentialterm
    -w_shape * phi(s) addieren. Keine neue Done-Regel; fuer den geplanten Pilot
    zusammen mit reward_fix=True. Default False erhaelt bisherige Rewards."""
    home_reserve: bool = False
    """29.10.2026 (Battle-Vorbereitung): Units, deren Ziel ein Punkte-Tile der Gegnerhaelfte weiter als
    far_opp Felder ist, warten stattdessen als Reserve im Ring mit Abstand 2 um die eigenen Punkte-Tiles
    (begehbar, kein Nebel, viel Feldenergie). Diagnose Dev A: Kennt der Belief mehr Punkte-Tiles als wir
    Units haben, liefen die uebrigen Units 25 Felder in die besetzte Gegnerfestung, starben und
    liefen nach dem Respawn wieder los (800070, Match 3). Faellt ein Halter, ist eine Reserve nah dran."""
    relic_scout: int = 0
    """29.10.2026: so viele ueberzaehlige Units (Ziel weit in der Gegnerhaelfte) suchen in Match 2/3 bis
    scout_until das neue Relic-Paar, solange es fehlen kann (features._relic_scout). Diagnose 800004: ein
    Paar aus Match 2 wurde nie gefunden, wir kannten 38-44 % der Punkte-Tiles. Units mit eigenem Ziel nie."""
    scout_until: int = 60
    scout_stale: int = 20
    relic_prior: float = 0.0
    """> 0 (01.11.2026, nur Auswertung): Erkundungsziele nach der Lage-Verteilung der Relics. Die Engine setzt
    die Relics auf die hoechsten Werte eines Perlin-Rauschens aus 4x4 Zellen zu je 6 Tiles (luxai_s3/state.py,
    gen_map). Auf 10.000 Karten (39.762 Knoten) liegen 96,8 % aller Relic-Knoten auf Tiles mit x%6 oder y%6 in
    {2, 3} (56 % der Karte), 30 % in den 2x2-Kernen (x%6, y%6) in {2, 3}^2 und keiner bei x%6 und y%6 in {0, 5}
    (features.RELIC_P6). Statt des unerkundeten Tiles naechst der Blockmitte wird je 4x4-Block das begehbare
    Tile Ziel, von dem aus in Sichtweite am meisten noch unerkundete Relic-Wahrscheinlichkeit liegt; Bloecke
    ohne solche entfallen. Ziele mit mehr sichtbarer Wahrscheinlichkeit kosten bis zu relic_prior Felder
    weniger. Diagnose (V13 gegen Solution_92, Dev A, Sichtweite 1): das erste Relic-Paar ist im Median erst
    9 Schritte nach dem Spawn bekannt (Sicht 3/4: 1), ein Orakel mit allen Relics bringt dort +4,9 pp."""
    spawn_proof: bool = False
    """True (01.11.2026, nur Auswertung): Im Match j >= 1 beweist ein Punkt, den kein bekanntes Relic erklaeren kann,
    den Spawn des Paars j (alle frueheren Paare bekannt); die Punkte-Inferenz darf dann vor match_step 50 schliessen
    (Belief._check_spawn_proof). Sonst ist sie im 2./3. Match im Mittel 41-47 Schritte gesperrt."""
    cand_post: float = 0.0
    """> 0 (01.11.2026, nur Auswertung): Kandidaten-Tiles mit hoeherer Punkte-Wahrscheinlichkeit zuerst testen. Ein
    Tile in k Relic-Zonen ist auf 1.500 Karten zu 20 / 34 / 49 / 57 % (k = 1 / 2 / 3 / 4+) ein Punkte-Tile; offene
    Gleichungen des Gedaechtnisses (rest Punkte auf n Tiles) geben rest / n. Kosten je Kandidat minus cand_post mal
    Wahrscheinlichkeit (features.cand_probs). Diagnose: Bis alle Punkte-Tiles einer neuen Zone bewiesen sind,
    vergehen 30-40 Schritte; mit den wahren Punkte-Tiles gewinnt V13 bei Sichtweite 1 gegen Solution_92 94,4 statt
    85,4 % (Orakel nur Punkte-Tiles, Dev A)."""
    reserve_sap: bool = False
    """29.10.2026: Reserve-Units (home_reserve) auf ihrem Reservetile sappen wie Halter (pt_sap-Regeln)."""
    active_targets: bool = False
    """True: nur Units mit Energie >= 0 erhalten Ziele; sonstige Features bleiben
    unveraendert. Default False erhaelt das Verhalten alter Checkpoints."""
    smart_sap: bool = False
    """True: Sap-Ziel mit Teamabstimmung (rules.plan_sap): kein Overkill,
    stehende Gegner/Gegner auf Punkte-Tiles bevorzugt, Abschuss-Bonus; lohnt
    sich kein Sap mehr, bleibt die Unit stehen."""
    use_shaping: bool = True
    """False: Reward = w_point (auf bewiesenem Punkte-Tile) + w_match * Env-Reward.
    Ohne Potential-, Explore-, Discovery-, Stack-, Energie-, Tod- und Sap-Terme."""
    canonical: bool = True
    """False: keine Spiegelung; je Seite ein eigenes Netz (agent_p0/agent_p1)."""

    # --- Aktionen
    use_sap: bool = True              # 6. Aktion: Sap auf heuristisch bestes Ziel
    mask_actions: bool = True         # Asteroiden/Kartenrand/Sap ohne Ziel maskieren

    # --- Reward Shaping (siehe reward.py)
    w_point: float = 1.0
    w_shape: float = 0.5
    w_explore: float = 0.3
    w_energy: float = 0.1
    w_stack: float = 0.3
    w_death: float = 0.5
    w_match: float = 2.0
    w_discovery: float = 0.5
    w_sap_hit: float = 0.3
    fog_unknown_reward_neutral: bool = False
    """True: finalen Fog-SAP ohne bekannte Trefferschätzung im Hit-Shaping neutral
    behandeln. Aktion und numerische Trefferschätzung bleiben unverändert."""
    w_opp_points: float = 0.0
    """> 0: Strafe je Gegner-Punkt in diesem Step, auf das Team verteilt (19.10.)."""

    # --- Abgabe
    frozen: bool = False
    """True (29.10.2026, nur in der Battle-Abgabe gesetzt): Der Kurs-Runner erzeugt Agenten ohne
    train-Argument (Default True) und ruft bei train=True update() und save_agent() auf. Dann spielte
    Sherlock mit nur einem Netz, ohne die meisten Regeln und mit Epsilon und ueberschriebe seine .pth.
    Eingefroren spielt er immer wie mit train=False (alle Netze, alle Regeln, kein Epsilon), lernt
    nicht und schreibt ohne ausdruecklichen Pfad nichts."""

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "AgentConfig":
        """Unbekannte Schluessel ignorieren (aeltere/neuere Checkpoints)."""
        known = {f.name for f in fields(cls)}
        return cls(**{k: v for k, v in (d or {}).items() if k in known})
