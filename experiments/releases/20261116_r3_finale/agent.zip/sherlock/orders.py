import numpy as np
from .v14 import geometry as geo
from .v14.imitation_agent import canonical_action

ARMS = ("movement",)


def native_order(row, position, energy, cfg, tiles):
    """World actions. Unknown tiles remain available. The engine clips off-board moves."""
    a, dx, dy = map(int, row)
    x, y = map(int, position)
    w, h = tiles.shape
    if a == geo.STAY:
        return True
    if a == geo.SAP:
        return (energy >= cfg["unit_sap_cost"] and max(abs(dx), abs(dy)) <= cfg["unit_sap_range"]
                and 0 <= x + dx < w and 0 <= y + dy < h)
    if not 1 <= a <= 4 or energy < cfg["unit_move_cost"]:
        return False
    nx, ny = x + int(geo.DIR_DX[a]), y + int(geo.DIR_DY[a])
    # Match JAX's tile lookup before clipping: -1 indexes the last tile;
    # a positive index beyond a dimension indexes its last tile.
    return tiles[min(nx, w - 1), min(ny, h - 1)] != 2


def live_ids(public, team):
    energy = np.asarray(public["units"]["energy"])[team].reshape(-1)
    return np.flatnonzero(np.asarray(public["units_mask"])[team] & (energy >= 0))


def substitute(actor, public, base, advice, arm, counts):
    """Edit a copy of V14's final world actions; update its per-unit canonical records."""
    if arm == "control" or int(public["match_steps"]) == 0:
        return base
    if arm not in ARMS:
        raise ValueError(arm)
    ctx = actor._prev_ctx
    played = base.copy()
    team = actor.team_id
    energies = np.asarray(public["units"]["energy"])[team].reshape(-1)
    positions = np.asarray(public["units"]["position"])[team]
    tiles = np.asarray(public["map_features"]["tile_type"])
    changed = set()
    for uid in live_ids(public, team):
        before, after = int(base[uid, 0]), int(advice[uid, 0])
        combat = before == geo.SAP or after == geo.SAP
        if (arm == "combat") != combat or np.array_equal(base[uid], advice[uid]):
            continue
        if not native_order(advice[uid], positions[uid], energies[uid], actor.env_cfg, tiles):
            counts["rejected_orders"] += 1
            continue
        changed.add(int(uid))
        played[uid] = advice[uid]
        a, dx, dy = canonical_action(advice[uid], actor.belief.mirrored)
        actor._prev_actions[uid] = a
        old_hits = actor._sap_hits.pop(uid, 0)
        actor._sap_unknown.discard(uid)
        new_hits = 0
        if a == geo.SAP:
            target = ctx["ally_pos"][uid] + (dx, dy)
            visible = ctx["enemy_coords"][ctx["enemy_energies"] >= 0]
            new_hits = int(np.sum(np.all(np.abs(visible-target) <= 1, axis=1)))
            actor._sap_hits[uid] = new_hits
            world_target = positions[uid] + advice[uid, 1:]
            if not public["sensor_mask"][tuple(world_target)]:
                actor._sap_unknown.add(uid)
        actor.ep_stats["sap_attempts"] += int(after == geo.SAP) - int(before == geo.SAP)
        actor.ep_stats["sap_hits_est"] += int(new_hits > 0) - int(old_hits > 0)
        kind = ("retarget" if before == after == geo.SAP else "new_sap" if after == geo.SAP
                else "skip_sap" if before == geo.SAP else "movement")
        counts[kind] += 1
    if changed:
        counts["changed_steps"] += 1
        counts["changed_unit_orders"] += len(changed)
        if actor.cfg.dodge_verify or actor.cfg.dodge_distrust > 0:
            from .v14.opp_model import predict_sol92_saps
            # A predicted shooter contributes >= .5, the stock reporting threshold.
            shape = actor._sap_shape() if actor.cfg.dodge_shape else "man"
            predicted = {uid for _, uid in predict_sol92_saps(ctx, actor.belief, shape=shape)}
            actor._pred_pending = [p for p in actor._pred_pending if p[0] not in changed]
            for uid in sorted(changed & predicted):
                a = actor._prev_actions[uid]
                if a in (geo.STAY, geo.SAP):
                    x, y = map(int, ctx["ally_pos"][uid])
                    actor._pred_pending.append((uid, x, y, float(energies[uid]), a == geo.SAP))
        if actor.cfg.dodge_shape:
            actor._shape_pending.clear()
            actor._record_shapes(ctx)
    return played
